INSERT INTO Accounts VALUES(6,'Jane', 'Calamity', 'Jane.Calamity@somewhere.com', 'Oui', 200);
INSERT INTO Accounts VALUES(7,'Lucky', 'Luke', 'Lucky.Luke@somewhere.com', 'Oui', 200);
INSERT INTO Accounts VALUES(8,'Ming', 'Li Foo', null), 'Non', 100;
INSERT INTO Accounts VALUES(9,'O''Hara', 'Steve', 'Jack.OHara@somewhere.com', 'Oui', 200);
INSERT INTO Accounts VALUES(10,'Robert', 'O''Timmins', null, 'Non', 100);

