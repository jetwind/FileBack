
use IBatisNet;