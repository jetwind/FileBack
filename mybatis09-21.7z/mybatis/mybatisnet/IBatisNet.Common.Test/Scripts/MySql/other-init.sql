
use iBatisNet;

drop table if exists OTHERS;

create table OTHERS
(
   OTHER_INT                       int,
   OTHER_LONG                     bigint
) TYPE=INNODB;

INSERT INTO Others VALUES(1, 8888888);
INSERT INTO Others VALUES(2, 9999999999);