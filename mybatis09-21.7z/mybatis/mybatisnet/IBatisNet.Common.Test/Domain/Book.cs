namespace IBatisNet.Common.Test.Domain
{
	/// <summary>
	/// Summary description for Book.
	/// </summary>
	public class Book : Document 
	{
		public Book()
		{
		}
	}
}
