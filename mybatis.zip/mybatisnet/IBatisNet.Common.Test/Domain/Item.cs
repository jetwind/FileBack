using System;

namespace IBatisNet.Common.Test.Domain
{
	/// <summary>
	/// Summary description for Item.
	/// </summary>
	public class Item
	{
		protected Item()
		{
		}
	}

    public class ItemBis
    {
        public ItemBis(string description)
        {
        }
    }
}
