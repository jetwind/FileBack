#if dotnet2
using System.Collections.Generic;

namespace IBatisNet.Common.Test.Domain
{
    public class GenericDocumentCollection : List<Document>
    {
    }
}
#endif
