using System;

namespace IBatisNet.Common.Test.Domain
{
	/// <summary>
	/// Summary description for Order.
	/// </summary>
	public class Order
	{
		private Order()
		{
		}
	}
}
