drop table OTHERS;

create table OTHERS
(
   OTHER_INT                       long,
   OTHER_LONG                      decimal
);

INSERT INTO Others VALUES(1, 8888888);
INSERT INTO Others VALUES(2, 9999999999);